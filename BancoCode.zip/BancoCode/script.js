const apiUrl = "https://localhost:7031/api";

async function verificarCuenta() {
  const numero = document.getElementById("verificarCuenta").value.trim();
  const resultado = document.getElementById("resultadoVerificacion");

  try {
    const res = await fetch(`${apiUrl}/Banco/cuenta-existe/${numero}`);
    const existe = await res.json();

    if (res.ok) {
      resultado.textContent = existe ? "✅ Cuenta existente" : "❌ Cuenta no encontrada";
      resultado.style.color = existe ? "lime" : "red";
    } else {
      resultado.textContent = "❌ Error al verificar la cuenta";
      resultado.style.color = "orange";
    }
  } catch (err) {
    resultado.textContent = "❌ Error de conexión con el servidor";
    resultado.style.color = "orange";
  }
}

async function realizarTransferencia() {
  const origen = document.getElementById("cuentaOrigen").value.trim();
  const destino = document.getElementById("cuentaDestino").value.trim();
  const valor = parseFloat(document.getElementById("valorTransferencia").value);
  const resultado = document.getElementById("resultadoTransferencia");

  if (!origen || !destino || isNaN(valor) || valor <= 0) {
    resultado.textContent = "❌ Rellena todos los campos correctamente.";
    resultado.style.color = "orange";
    return;
  }

  const body = {
    numero: 0,
    fecha: new Date().toISOString(),
    valor: valor,
    cuentaOrigen: origen,
    cuentaDestino: destino
  };

  try {
    const res = await fetch(`${apiUrl}/Transferencias/realizar`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });

    const data = await res.json();
    resultado.textContent = data.mensaje || "Error";
    resultado.style.color = res.ok ? "lime" : "red";
  } catch (error) {
    resultado.textContent = "❌ Error al conectar con la API.";
    resultado.style.color = "red";
  }
}

